package com.pusher.chatkit.util

import java.text.SimpleDateFormat
import java.util.*

internal val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH)
